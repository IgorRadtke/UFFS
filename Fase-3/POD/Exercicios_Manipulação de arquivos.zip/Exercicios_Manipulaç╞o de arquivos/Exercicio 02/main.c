#include <stdio.h>
int Vet[20];

void quicksort(int *target, int left, int right) {
  if(left >= right){
    return;
  }
  int i = left, j = right;

  int tmp, pivot = target[i];
  
  for(;;) {
    while(target[i] < pivot){ 
      i++;
    }  
    while(pivot < target[j]){ 
      j--;
    }  
    if(i >= j){ 
      break;
    }  
    tmp = target[i]; target[i] = target[j]; target[j] = tmp;
    i++; j--;
  }
  quicksort(target, left, i-1);
  quicksort(target, j+1, right);
}

int main(void) {
  FILE *file;
  file = fopen("numeros.txt", "r");
  if (file == NULL){
    printf("Este arquivo não pode ser aberto :(");
    system("Pausa");
    return 0;
  }
  int S, x;
  S = 0;
  x = 20;
  do{
      fscanf(file, "%d", &Vet[S]);
      S+=1;
  }while (x!=S);
  quicksort(Vet, 0, 19);
  for (int i = 0; i < 20; i++) {
    printf("%d ", Vet[i]);
  }
  return 0;
}