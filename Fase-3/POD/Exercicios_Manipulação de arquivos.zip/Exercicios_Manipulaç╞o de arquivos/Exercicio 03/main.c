#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct aluno {
    char nome[51];
    float n1;
    float n2;
    int media;
} Aluno;

void quicksort(Aluno *t, int left, int right) {
  if(left >= right){
    return;
  }
  int i = left, j = right;

  int tmp, pivot = t[i].media;

  for(;;) {
    while(t[i].media < pivot){ 
      i++;
    }
    while(pivot < t[j].media){ 
      j--;
    }
    if(i >= j){ 
      break;
    }
    tmp = t[i].media; t[i] = t[j]; t[j].media = tmp;
    i++; j--;
  }
  quicksort(t, left, i-1);
  quicksort(t, j+1, right);
}


int main(void) {
  FILE *file;
  file = fopen("numeros.txt", "r");
  if (file == NULL){
    printf("Este arquivo não pode ser aberto :(");
    system("Pausa");
    return 0;

  }
  int sa;
  int z, X;
  char f[500];
  fscanf(file, "%d", &sa);
  printf("%d\n ", sa);


Aluno aluno[] = {};
 X = 0;
 z = sa;
  do{
      fscanf(file, "%s", f);
      strcpy(aluno[X].nome, f);
      fscanf(file, "%f", &aluno[X].n1);
      fscanf(file, "%f", &aluno[X].n2);
      X+=1;
  }while (z!=X);

  for (int i = 0; i < sa; i++){
    aluno[i].media = (aluno[i].n1 + aluno[i].n2)/2;
  }

  quicksort(aluno, 0, sa-1);
  for (int i = 0; i < sa; i++) {
    printf("Nome: %s Média: %d ", aluno[i].nome, aluno[i].media);
  }
  fclose(file);
  return 0;
}