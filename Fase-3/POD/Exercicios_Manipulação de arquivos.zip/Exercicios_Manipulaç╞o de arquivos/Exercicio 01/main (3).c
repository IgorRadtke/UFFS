#include <stdio.h>
#include <stdlib.h>

int main() {
    FILE *X = fopen("numeros.txt", "rt");
    int Geral = 0, Linha = 0, espaco = 0, c= 0;
    if (X == NULL) {
        printf("Erro!");
        exit(1);
    }

    while (!feof(X)) {

        c = fgetc(X);
        if (c == '\n') {
            Linha ++;
        }
        else if (c == ' ') {
            espaco ++;
        }
        else {
            Geral ++;
        }
    }
    printf("Caracteres em geral é: %d\n", Geral);
    printf("Espacos é: %d\n", espaco);
    printf("Quebras de linhas : %d\n", Linha);
    fclose(X);

    return 0;
}