#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct aluno {
    char nome[51];
    float n1, n2;
} Aluno;


int main(void) {
  FILE *file;
  file = fopen("numeros.txt", "r");
  if (file == NULL){
    printf("Este arquivo nao pode ser aberto :(");
    system("Pausa");
    return 0;

  }
  
  int E;
  int Y, Z;
  char f[250];
  printf("Init");
  fscanf(file, "%d", &E);
  printf("%d\n ", E);
  

Aluno aluno[] = {};
 Z = 0;
 Y = E;
  do{
      fscanf(file, "%s", f);
      strcpy(aluno[Z].nome, f);
      fscanf(file, "%f", &aluno[Z].n1);
      fscanf(file, "%f", &aluno[Z].n2);
      Z+=1;
  }while (Y!=Z);

  for (int i = 0; i < E; i++) {
    printf("Name: %s ", aluno[i].nome);
  }
  fclose(file);
  return 0;
}